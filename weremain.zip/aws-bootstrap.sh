#!/bin/bash -x
apt-get update
npm install
node server.js
